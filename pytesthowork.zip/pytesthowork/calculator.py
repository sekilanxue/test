class Calculator:
    def add(self,a,b):
        return a + b
    def div(self,a,b):
        return a / b